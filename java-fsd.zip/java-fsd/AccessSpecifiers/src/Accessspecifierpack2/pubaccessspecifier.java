package Accessspecifierpack2;

import Accessspecifierpack1.*;

public class pubaccessspecifier {

public static void main(String[] args) {
		
		pubaccessspecifier obj = new pubaccessspecifiers(); 
        obj.display();  
		
	}

private void display() {
	// TODO Auto-generated method stub
	
}

}
