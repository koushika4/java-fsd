package pac1;

public class pubaccspec {

	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 
}
