package pac1;

public class proaccspec {

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}
