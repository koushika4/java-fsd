package pac2;

public class accSpec3 {

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}
