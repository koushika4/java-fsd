package pac2;

import pac1.*;

public class accSpec4 extends proaccessspecifiers {

	public static void main(String[] args) {
		accSpec4 obj = new accSpec4 ();   
	       obj.display();
	       
	}

}
